package quiz;

import db.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class QuizService {
    public boolean createQuiz(String title, int adminId) {
        try (Connection conn = Database.getConnection()) {
            String query = "INSERT INTO quizzes (title, created_by) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, title);
            ps.setInt(2, adminId);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}

