package uifx;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
    
        FXMLLoader loader =new FXMLLoader(getClass().getResource("mainScene.fxml"));
        LoginUI loginUI = new LoginUI();
        loginUI.start(primaryStage);
    }

    public static void main(String[] args) {
        launch(args); 
    }
}
