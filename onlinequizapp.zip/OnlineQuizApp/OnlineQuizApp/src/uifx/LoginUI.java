package uifx;

import auth.AuthService;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class LoginUI extends Application {
    private AuthService authService;

    public LoginUI() {
        authService = new AuthService();
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Login");

        // Create GridPane for layout
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        // Username field
        Label usernameLabel = new Label("Username:");
        GridPane.setConstraints(usernameLabel, 0, 0);

        TextField usernameInput = new TextField();
        GridPane.setConstraints(usernameInput, 1, 0);

        // Password field
        Label passwordLabel = new Label("Password:");
        GridPane.setConstraints(passwordLabel, 0, 1);

        PasswordField passwordInput = new PasswordField();
        GridPane.setConstraints(passwordInput, 1, 1);

        // Login Button
        Button loginButton = new Button("Login");
        GridPane.setConstraints(loginButton, 1, 2);
        loginButton.setOnAction(e -> {
            String username = usernameInput.getText();
            String password = passwordInput.getText();

            boolean loginSuccessful = authService.loginUser(username, password);
            if (loginSuccessful) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Login successful!");
                alert.showAndWait();

                // Navigate to the Admin Dashboard or Quiz List based on the role
                if (authService.isAdmin(username)) {
                    AdminDashboardUI adminDashboard = new AdminDashboardUI();
                    adminDashboard.start(primaryStage);
                } else {
                    QuizTakingUI quizTaking = new QuizTakingUI();
                    quizTaking.start(primaryStage);
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid credentials. Try again.");
                alert.showAndWait();
            }
        });

        // Register Button
        Button registerButton = new Button("Register");
        GridPane.setConstraints(registerButton, 1, 3);
        registerButton.setOnAction(e -> {
            String username = usernameInput.getText();
            String password = passwordInput.getText();

            boolean registrationSuccessful = authService.registerUser(username, password);
            if (registrationSuccessful) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Registration successful! You can now log in.");
                alert.showAndWait();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Registration failed. Username might already exist.");
                alert.showAndWait();
            }
        });

        // Add components to the grid
        grid.getChildren().addAll(usernameLabel, usernameInput, passwordLabel, passwordInput, loginButton, registerButton);

        // Set up the scene and stage
        Scene scene = new Scene(grid, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
