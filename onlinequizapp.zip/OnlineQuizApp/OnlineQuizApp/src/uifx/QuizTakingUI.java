package uifx;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import quiz.QuizService;

public class QuizTakingUI extends Application {
    @Override
    public void start(Stage primaryStage) {
        QuizService quizService = new QuizService();

        Label questionLabel = new Label("Question:");
        ToggleGroup optionsGroup = new ToggleGroup();

        RadioButton option1 = new RadioButton("Option 1");
        option1.setToggleGroup(optionsGroup);

        RadioButton option2 = new RadioButton("Option 2");
        option2.setToggleGroup(optionsGroup);

        Button nextButton = new Button("Next");
        Button submitButton = new Button("Submit");

        nextButton.setOnAction(e -> {
            // Load next question
        });

        submitButton.setOnAction(e -> {
            // Calculate and display score
        });

        VBox layout = new VBox(10, questionLabel, option1, option2, nextButton, submitButton);
        Scene scene = new Scene(layout, 400, 300);

        primaryStage.setTitle("Take Quiz");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
