package uifx;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AdminDashboardUI extends Application {
    @Override
    public void start(Stage primaryStage) {
        Button createQuizButton = new Button("Create Quiz");
        Button manageQuizzesButton = new Button("Manage Quizzes");

        createQuizButton.setOnAction(e -> {
            // Navigate to Create Quiz UI
        });

        manageQuizzesButton.setOnAction(e -> {
            // Navigate to Manage Quizzes UI
        });

        VBox layout = new VBox(10, createQuizButton, manageQuizzesButton);
        Scene scene = new Scene(layout, 300, 200);

        primaryStage.setTitle("Admin Dashboard");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
